package com.wc.socket;

import com.wc.database.DBQuery;
import com.wc.logic.Message;
import com.wc.database.Database;
import com.wc.logic.RecieveFile;
import com.wc.logic.SendFile;
import com.wc.ui.ServerFrame;
import java.io.*;
import java.net.*;
import java.nio.file.Files;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

class ServerThread extends Thread { 
	
    public SocketServer server = null;
    public Socket socket = null;
    public int ID = -1;
    public int count=0;
    public String username = "";
    public ObjectInputStream streamIn  =  null;
    public ObjectOutputStream streamOut = null;
    public ServerFrame ui;
   

    public ServerThread(SocketServer _server, Socket _socket){  
    	super();
        server = _server;
        socket = _socket;
        ID     = socket.getPort();
        ui = _server.ui;
    }
    
    public void send(Message msg){
        try {
            streamOut.writeObject(msg);
            streamOut.flush();
        } 
        catch (IOException ex) {
            System.out.println("Exception [SocketClient : send(...)]");
        }
    }
    
    public int getID(){  
	    return ID;
    }
   
    @SuppressWarnings("deprecation")
	public void run(){  
    	ui.jTextArea1.append("\nServer Thread " + ID + " running.");
        while (true){  
    	    try{  
                Message msg = (Message) streamIn.readObject();
    	    	server.handle(ID, msg);
            }
            catch(Exception ioe){  
               System.out.println(ID + " ERROR reading: " + ioe.getMessage());
               server.remove(ID);
               stop();
            }
        }
    }
    
    public void open() throws IOException {  
        streamOut = new ObjectOutputStream(socket.getOutputStream());
        streamOut.flush();
        streamIn = new ObjectInputStream(socket.getInputStream());
    }
    
    public void close() throws IOException {  
    	if (socket != null)    socket.close();
        if (streamIn != null)  streamIn.close();
        if (streamOut != null) streamOut.close();
    }
}





public class SocketServer implements Runnable {
    
    public ServerThread clients[];
    public ServerSocket server = null;
    public Thread       thread = null;
    public int clientCount = 0, port;
    public ServerFrame ui;
    public String[] onlineUsers=new String[50];
    //public Database db;

    public SocketServer(ServerFrame frame){
        try
        {
                 port=Integer.parseInt(frame.jTextField4.getText());
        }
  catch(Exception ex)
  {
      JOptionPane.showMessageDialog(frame, "Restart Server and Enter Valid Port number");
      return;
  }
        clients = new ServerThread[50];
        ui = frame;
       // db = new Database(ui.filePath);
        
	try{  
	    server = new ServerSocket(port);
            port = server.getLocalPort();
	    ui.jTextArea1.append("Server started. IP : " + InetAddress.getLocalHost() + ", Port : " + server.getLocalPort());
	    start(); 
        }
	catch(IOException ioe){  
            ui.jTextArea1.append("Can not bind to port : " + port + "\nRetrying"); 
            ui.RetryStart(0);
	}
    }
    
    public SocketServer(ServerFrame frame, int Port){
       
        clients = new ServerThread[50];
        ui = frame;
        port = Port;
        //db = new Database(ui.filePath);
        
	try{  
	    server = new ServerSocket(port);
            port = server.getLocalPort();
	    ui.jTextArea1.append("Server startet. IP : " + InetAddress.getLocalHost() + ", Port : " + server.getLocalPort());
	    start(); 
        }
	catch(IOException ioe){  
            ui.jTextArea1.append("\nCan not bind to port " + port + ": " + ioe.getMessage()); 
	}
    }
	
    public void run(){  
	while (thread != null){  
            try{  
		ui.jTextArea1.append("\nWaiting for a client ..."); 
	        addThread(server.accept()); 
	    }
	    catch(Exception ioe){ 
                ui.jTextArea1.append("\nServer accept error: \n");
                ui.RetryStart(0);
	    }
        }
    }
	
    public void start(){  
    	if (thread == null){  
            thread = new Thread(this); 
	    thread.start();
	}
    }
    
    @SuppressWarnings("deprecation")
    public void stop(){  
        if (thread != null){  
            thread.stop(); 
	    thread = null;
	}
    }
    
    private int findClient(int ID){  
    	for (int i = 0; i < clientCount; i++){
        	if (clients[i].getID() == ID){
                    return i;
                }
	}
	return -1;
    }
	
    public synchronized void handle(int ID, Message msg) throws IOException{  
	if (msg.content.equals(".bye")){
            Announce("signout", "SERVER", msg.sender);
            remove(ID); 
	}
	else{
            if(msg.type.equals("login")){
                if(findUserThread(msg.sender) == null){
                        clients[findClient(ID)].username = msg.sender;
                        clients[findClient(ID)].send(new Message("login", "SERVER", "TRUE", msg.sender));
                        Announce("newuser", "SERVER", msg.sender);
                        SendUserList(msg.sender);
               }
                else{
                    clients[findClient(ID)].send(new Message("login", "SERVER", "FALSE", msg.sender));
                }
            }
            else if(msg.type.equals("deleted")){
                Announce("deleted", "SERVER", msg.content);
            }
            else if(msg.type.equals("added")){
                Announce("added", "SERVER", msg.content);
            }
            else if(msg.type.equals("modified")){
                Announce("modified", "SERVER", msg.content);
            }
            else if(msg.type.equals("noticeAdd")){
                Announce("noticeAdd", "SERVER", msg.content);
            }
            else if(msg.type.equals("noticeModified")){
                Announce("noticeModified", "SERVER", msg.content);
            }
            else if(msg.type.equals("message")){
                if(msg.reciever.equals("All")){
                    Announce("message", msg.sender, msg.content);
                }
                else{
                    findUserThread(msg.reciever).send(new Message(msg.type, msg.sender, msg.content, msg.reciever));
                    clients[findClient(ID)].send(new Message(msg.type, msg.sender, msg.content, msg.reciever));
                }
            }
            else if(msg.type.equals("offline")){
                findUserThread(msg.reciever).send(new Message("message",msg.sender,msg.content,msg.reciever));
                //clients[findClient(ID)].send(new Message("message", msg.sender, msg.content, msg.reciever));
            }
            else if(msg.type.equals("offlineFile")){
                findUserThread(msg.reciever).send(new Message("upload_req_offline_check",msg.sender,msg.content,msg.reciever));
            }            
            else if(msg.type.equals("test")){
                clients[findClient(ID)].send(new Message("test", "SERVER", "OK", msg.sender));
            }
//            else if(msg.type.equals("signup")){
            //                if(findUserThread(msg.sender) == null){
            //                    if(!db.userExists(msg.sender)){
            //                        db.addUser(msg.sender, msg.content);
            //                        clients[findClient(ID)].username = msg.sender;
            //                        clients[findClient(ID)].send(new Message("signup", "SERVER", "TRUE", msg.sender));
            //                        clients[findClient(ID)].send(new Message("login", "SERVER", "TRUE", msg.sender));
            //                        Announce("newuser", "SERVER", msg.sender);
            //                        SendUserList(msg.sender);
            //                    }
            //                    else{
            //                        clients[findClient(ID)].send(new Message("signup", "SERVER", "FALSE", msg.sender));
            //                    }
            //                }
            //                else{
            //                    clients[findClient(ID)].send(new Message("signup", "SERVER", "FALSE", msg.sender));
            //                }
            //            }
            else if(msg.type.equals("upload_req")||msg.type.equals("upload_img_req")){
                if(msg.reciever.equals("All")){
                    clients[findClient(ID)].send(new Message("message", "SERVER", "Uploading to 'All' forbidden", msg.sender));
                }
                else{
                    findUserThread(msg.reciever).send(new Message(msg.type, msg.sender, msg.content, msg.reciever));
                }
            }
            else if(msg.type.equals("upload_req_offline")||msg.type.equals("upload_img_req_offline")){
                //jf.setSelectedFile(new File(msg.content));
                //int returnVal = jf.showSaveDialog(ui);
                String saveTo="E:\\WEConnect\\"+msg.content;
                //String saveTo = jf.getSelectedFile().getPath();
                if (saveTo != null) {
                    RecieveFile dwn = new RecieveFile(saveTo);
                    Thread t = new Thread(dwn);
                    t.start();
                    String IP = Inet4Address.getLocalHost().getHostAddress();
                    //send(new Message("upload_res", (""+InetAddress.getLocalHost().getHostAddress()), (""+dwn.port), msg.sender));
                    clients[findClient(ID)].send(new Message("upload_res", IP, ("" + dwn.port), msg.sender));
                } else {
                    clients[findClient(ID)].send(new Message("upload_res","SERVER", "NO", msg.sender));
                }
            }
            else if(msg.type.equals("upload_res")||msg.type.equals("upload_img_res")){
                if(!msg.content.equals("NO")){
                    String IP = findUserThread(msg.sender).socket.getInetAddress().getHostAddress();
                    System.out.println(IP);
                    findUserThread(msg.reciever).send(new Message(msg.type, IP, msg.content, msg.reciever));
                }
                else{
                    findUserThread(msg.reciever).send(new Message(msg.type, msg.sender, msg.content, msg.reciever));
                }
            }
            else if(msg.type.equals("upload_res_offline")){
               if (!msg.content.equals("NO")) {
                            int port = Integer.parseInt(msg.content);
                            String addr = msg.sender;
                            String filePath="E:\\WEConnect\\"+msg.reciever;
                            File naya=new File(filePath);
                            SendFile upl = new SendFile(addr, port,naya);
                            Thread t = new Thread(upl);
                            t.start();
                    } 
                    else {
                        System.out.println(msg.sender + " rejected file request\n");
                    }
            }
            
	}
    }
    
    public void Announce(String type, String sender, String content){
        Message msg = new Message(type, sender, content, "All");
        for(int i = 0; i < clientCount; i++){
            clients[i].send(msg);
        }
    }
    
    public void SendUserList(String toWhom){
        for(int i = 0; i < clientCount; i++){
            findUserThread(toWhom).send(new Message("newuser", "SERVER", clients[i].username, toWhom));
        }
    }
    
    public ServerThread findUserThread(String usr){
        for(int i = 0; i < clientCount; i++){
            if(clients[i].username.equals(usr)){
                return clients[i];
            }
        }
        return null;
    }
	
    @SuppressWarnings("deprecation")
    public synchronized void remove(int ID){  
    int pos = findClient(ID);
        if (pos >= 0){  
            ServerThread toTerminate = clients[pos];
            ui.jTextArea1.append("\nRemoving client thread " + ID + " at " + pos);
	    if (pos < clientCount-1){
                for (int i = pos+1; i < clientCount; i++){
                    clients[i-1] = clients[i];
	        }
	    }
	    clientCount--;
	    try{  
	      	toTerminate.close(); 
	    }
	    catch(IOException ioe){  
	      	ui.jTextArea1.append("\nError closing thread: " + ioe); 
	    }
	    toTerminate.stop(); 
	}
    }
    
    private void addThread(Socket socket){  
	if (clientCount < clients.length){  
            ui.jTextArea1.append("\nClient accepted: " + socket);
	    clients[clientCount] = new ServerThread(this, socket);
	    try{  
	      	clients[clientCount].open(); 
	        clients[clientCount].start();  
	        clientCount++; 
	    }
	    catch(IOException ioe){  
	      	ui.jTextArea1.append("\nError opening thread: " + ioe); 
	    } 
	}
	else{
            ui.jTextArea1.append("\nClient refused: maximum " + clients.length + " reached.");
	}
    }
}
