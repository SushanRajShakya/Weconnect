package com.wc.database;

import java.sql.*;
import javax.swing.JOptionPane;

public class DBConn {
    public static Connection getConnection(){
        try{
           Class.forName("com.mysql.jdbc.Driver");
           Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/weconnect","root","");
           return con;
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return null;
    }
}
