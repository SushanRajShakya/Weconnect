package com.wc.database;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class DBQuery {
    public Connection con=null;
    //constructor
    public DBQuery(){
        con=DBConn.getConnection();
    }
    //to check if the user is a valid user 
    public boolean checkLogin(String userID,String password){
        int i=0;
        try {
            String sql="select * from logindetails";
            Statement stmt=con.createStatement();
            ResultSet rs=stmt.executeQuery(sql);
            while(rs.next()){
                if(userID.equals(rs.getString(2)) && password.equals(rs.getString(3))){
                        return true;
                }
                else 
                    i=1;
            }
        } catch (SQLException ex) {
            Logger.getLogger(DBQuery.class.getName()).log(Level.SEVERE, null, ex);
            ex.printStackTrace();
        }
        if(i==1){
            JOptionPane.showMessageDialog(null, "Username or Password Incorrect!!!!!");
            return false;
        }
        return false;
    }
    //code to check if there is any message in database
   public String checkMsg(String userName){
        try {
            String sql="select * from tbl_message";
            Statement stmt=con.createStatement();
            ResultSet rs=stmt.executeQuery(sql);
            while(rs.next()){
                if(userName.equals(rs.getString(3))){
                   return rs.getString(2)+":"+rs.getString(3)+":"+rs.getString(4);
                }
                else
                   return null;
            }   
        } catch (SQLException ex) {
            Logger.getLogger(DBQuery.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    //code to save message if user is not online(not implemented yet)
    public void insertMsg(String sender,String receiver,String content){
        try {
            String sql="insert into tbl_message (Sender,Receiver,Content) values(?,?,?)";
            PreparedStatement pst=con.prepareStatement(sql);
            pst.setString(1, sender);
            pst.setString(2, receiver);
            pst.setString(3, content);
            pst.execute();
        } catch (SQLException ex) {
            Logger.getLogger(DBQuery.class.getName()).log(Level.SEVERE, null, ex);
        }
       
    }
    
    public void insertFile(String sender,String receiver,String content){
        try {
            String sql="insert into tbl_file (Sender,Receiver,FilePath) values(?,?,?)";
            PreparedStatement pst=con.prepareStatement(sql);
            pst.setString(1, sender);
            pst.setString(2, receiver);
            pst.setString(3, content);
            pst.execute();
        } catch (SQLException ex) {
            Logger.getLogger(DBQuery.class.getName()).log(Level.SEVERE, null, ex);
        }
       
    }
    //code for retreiving all the users in database to display on the screen
    public String[] offline(){
        int i=0;
        String offline[]=new String[50];
        try {
            String sql="select * from logindetails";    
            Statement stmt=con.createStatement();
            ResultSet rs=stmt.executeQuery(sql);
            while(rs.next()){
                offline[i]=rs.getString(2);
                i++;
            }        
        } catch (SQLException ex) {
            Logger.getLogger(DBQuery.class.getName()).log(Level.SEVERE, null, ex);
        }
        return offline;
    }
    //check if username and password exists
    public boolean checkmesseger(String sender,String receiver){
        try {
            String sql="select * from tbl_message";
            Statement stmt=con.createStatement();
            ResultSet rs=stmt.executeQuery(sql);
            while(rs.next()){
                if(sender.equals(rs.getString(2))&& receiver.equals(rs.getString(3))){
                    return true;
                }
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(DBQuery.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    //code to update message
    public void update(String sender,String receiver,String content){
        try {
            String msg = null;
            try {
                String sql="select * from tbl_message where Sender='"+sender+"' and Receiver='"+receiver+"'";
                Statement stmt=con.createStatement();
                ResultSet rs=stmt.executeQuery(sql);
                while(rs.next()){
                    msg=rs.getString(4);
                }
            } catch (SQLException ex) {
                Logger.getLogger(DBQuery.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            content=msg+":"+content;
            String sql="update tbl_message set Content=? where Sender=? and Receiver=?";
            PreparedStatement pst=con.prepareStatement(sql);
            pst.setString(1, content);
            pst.setString(2, sender);
            pst.setString(3,receiver);
            pst.execute();
        } catch (SQLException ex) {
            Logger.getLogger(DBQuery.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void updateFile(String sender,String receiver,String content){
        try {
            String path = null;
            try {
                String sql="select * from tbl_file where Sender='"+sender+"' and Receiver='"+receiver+"'";
                Statement stmt=con.createStatement();
                ResultSet rs=stmt.executeQuery(sql);
                while(rs.next()){
                    path=rs.getString(4);
                }
            } catch (SQLException ex) {
                Logger.getLogger(DBQuery.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            content=path+":"+content;
            String sql="update tbl_file set FilePath=? where Sender=? and Receiver=?";
            PreparedStatement pst=con.prepareStatement(sql);
            pst.setString(1, content);
            pst.setString(2, sender);
            pst.setString(3,receiver);
            pst.execute();
        } catch (SQLException ex) {
            Logger.getLogger(DBQuery.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    //code to remove message from database after read
    public void remove(String sender,String receiver){
        String sql="delete from tbl_message where Receiver='"+receiver+"' and Sender='"+sender+"'";
        try {
            Statement stmt=con.createStatement();
            stmt.execute(sql);
        } catch (SQLException ex) {
            Logger.getLogger(DBQuery.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void saveMsg(String sender,String receiver,String content){
        if(checkmesseger(sender, receiver)){
           update(sender,receiver, content);
        }
        else{
            insertMsg(sender, receiver, content);
        }
    }
    public void saveFile(String sender,String receiver,String content){
        if(checkmesseger(sender, receiver)){
           updateFile(sender,receiver, content);
        }
        else{
            insertFile(sender, receiver, content);
        }
    }    
    
    public void logOutAll() throws SQLException{
        String sql = "update logindetails set Last_active=? and login_status=?";
        PreparedStatement pst = con.prepareStatement(sql);
        String timeStamp = new SimpleDateFormat("yyyy/MM/dd_HH/mm/ss").format(Calendar.getInstance().getTime());
        pst.setString(1,timeStamp);
        pst.setString(2,"NO");
        pst.execute();
    }
}
