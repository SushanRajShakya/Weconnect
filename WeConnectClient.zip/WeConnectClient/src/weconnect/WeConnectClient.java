/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package weconnect;

import com.wc.socket.SocketClient;
import com.wc.ui.ChatFrame;
import com.wc.ui.LoginFrame;
import javax.swing.JOptionPane;

/**
 *
 * @author Partha
 */
public class WeConnectClient {

    ChatFrame cf;

    String serverAddr = "localhost";
    int port = 13000;

    public WeConnectClient() {
        new LoginFrame().setVisible(true);

    }

    public static void main(String[] args) {
        new WeConnectClient();
    }
}
