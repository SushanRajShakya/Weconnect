package com.wc.ui;

import com.wc.database.DBConn;
import com.wc.database.DBQuery;
import com.wc.logic.Message;
import com.wc.mailView.CheckingInbox;
import com.wc.noticeSection.NoticeAddFrame;
import com.wc.noticeSection.NoticeViewFrame;
import com.wc.socket.SocketClient;
import com.wc.userOptions.UserOptionsFrame;
import java.awt.event.KeyEvent;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import javax.swing.DefaultListModel;
import javax.swing.JFileChooser;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;
import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.LookAndFeel;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

public class ChatFrame extends javax.swing.JFrame {

    public SocketClient client;
    public int port;
    public String serverAddr, username, password,accountType;
    public Thread clientThread;
    public DefaultListModel model;
    public DefaultListModel model1;
    public File file;
    public HashMap chatwinlist;
    public HashMap chatwinindexlist;
    static int capture = 1;
    public String filepath = null;
    
    public DBQuery query=null;
    
    public ChatFrame() throws SQLException {
        initComponents();
       
        jPanel1.hide();
        jLabel6.hide();
        btnSendFile.setEnabled(false);
        this.setResizable(false);
        chatwinlist = new HashMap();
        chatwinindexlist = new HashMap();
        chatwinindexlist.put("All", chatpane.indexOfComponent(jTextArea1) + "");
        chatwinlist.put(chatpane.indexOfComponent(jTextArea1) + "", jTextArea1);
        
        this.setTitle("We-Connect Messenger");
        model.addElement("All");
        listOnline.setSelectedIndex(0);
        

        //jTextField6.setEditable(false);
        this.addWindowListener(new WindowListener() {

            @Override
            public void windowOpened(WindowEvent e) {
            }

            @Override
            public void windowClosing(WindowEvent e) {
                try {
                    if (JOptionPane.showConfirmDialog(ChatFrame.this, "Are you sure you want to Signout?", "Logout", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
                        query=new DBQuery();
                        query.updateStatus(username,"YES");
                        query.updateLast_login(username);
                        client.send(new Message("message", username, ".bye", "SERVER"));
                        clientThread.stop();
                        ChatFrame.this.dispose();
                        new LoginFrame().setVisible(true);
                    }
                } catch (Exception ex) {
                }
            }

            @Override
            public void windowClosed(WindowEvent e) {
            }

            @Override
            public void windowIconified(WindowEvent e) {
            }

            @Override
            public void windowDeiconified(WindowEvent e) {
            }

            @Override
            public void windowActivated(WindowEvent e) {
            }

            @Override
            public void windowDeactivated(WindowEvent e) {
            }
        });
    }

    public boolean isWin32() {
        return System.getProperty("os.name").startsWith("Windows");
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        mainPanel = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLayeredPane2 = new javax.swing.JLayeredPane();
        jLabel6 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        btnView = new javax.swing.JButton();
        btnUserOptions = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        listOnline = new javax.swing.JList();
        jScrollPane1 = new javax.swing.JScrollPane();
        servermes = new javax.swing.JTextArea();
        jScrollPane6 = new javax.swing.JScrollPane();
        txtMessage = new javax.swing.JTextArea();
        btnSend = new javax.swing.JButton();
        btnSendFile = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        chatpane = new javax.swing.JTabbedPane();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        btnMail = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("ChatApp");
        setBackground(new java.awt.Color(204, 204, 255));
        setBounds(new java.awt.Rectangle(200, 50, 0, 0));

        mainPanel.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createMatteBorder(3, 3, 3, 3, new java.awt.Color(0, 0, 0)), new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED)));
        mainPanel.setPreferredSize(new java.awt.Dimension(800, 650));

        jPanel3.setBackground(new java.awt.Color(153, 204, 255));
        jPanel3.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel3.setForeground(new java.awt.Color(0, 51, 51));

        jLabel6.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N

        javax.swing.GroupLayout jLayeredPane2Layout = new javax.swing.GroupLayout(jLayeredPane2);
        jLayeredPane2.setLayout(jLayeredPane2Layout);
        jLayeredPane2Layout.setHorizontalGroup(
            jLayeredPane2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jLayeredPane2Layout.createSequentialGroup()
                .addGap(337, 337, 337)
                .addComponent(jLabel6)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jLayeredPane2Layout.setVerticalGroup(
            jLayeredPane2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jLayeredPane2Layout.createSequentialGroup()
                .addGap(13, 13, 13)
                .addComponent(jLabel6)
                .addContainerGap(35, Short.MAX_VALUE))
        );
        jLayeredPane2.setLayer(jLabel6, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jPanel2.setBackground(new java.awt.Color(153, 204, 255));

        btnView.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        btnView.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/wc/images/warning.png"))); // NOI18N
        btnView.setText("Notices");
        btnView.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnViewActionPerformed(evt);
            }
        });

        btnUserOptions.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        btnUserOptions.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/wc/images/team.png"))); // NOI18N
        btnUserOptions.setText("User Options");
        btnUserOptions.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUserOptionsActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnUserOptions, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnView, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(btnView)
                .addComponent(btnUserOptions))
        );

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/wc/images/Logo.jpg"))); // NOI18N

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 102, 102));
        jLabel2.setText("We-Connect Messenger");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel2)
                        .addContainerGap(457, Short.MAX_VALUE))
                    .addComponent(jLayeredPane2)))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(0, 9, Short.MAX_VALUE)
                        .addComponent(jLabel2)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLayeredPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(5, 5, 5))
        );

        jPanel1.setBackground(new java.awt.Color(153, 204, 255));
        jPanel1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        listOnline.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createTitledBorder(null, "People Online", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 11), new java.awt.Color(0, 102, 102)), "People Online")); // NOI18N
        listOnline.setModel((model = new DefaultListModel()));
        listOnline.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        listOnline.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                listOnlineMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(listOnline);
        listOnline.getAccessibleContext().setAccessibleName("Online Status");

        servermes.setEditable(false);
        servermes.setColumns(20);
        servermes.setFont(new java.awt.Font("Monospaced", 1, 13)); // NOI18N
        servermes.setForeground(new java.awt.Color(0, 51, 153));
        servermes.setRows(5);
        servermes.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "System Messages", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 11), new java.awt.Color(0, 51, 153))); // NOI18N
        servermes.setDisabledTextColor(new java.awt.Color(0, 51, 153));
        servermes.setSelectionColor(new java.awt.Color(0, 51, 153));
        jScrollPane1.setViewportView(servermes);

        txtMessage.setColumns(20);
        txtMessage.setRows(5);
        txtMessage.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createTitledBorder("Message Here")));
        txtMessage.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtMessageKeyReleased(evt);
            }
        });
        jScrollPane6.setViewportView(txtMessage);

        btnSend.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        btnSend.setForeground(new java.awt.Color(0, 51, 51));
        btnSend.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/wc/images/message.png"))); // NOI18N
        btnSend.setText("Send");
        btnSend.setEnabled(false);
        btnSend.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSendActionPerformed(evt);
            }
        });
        btnSend.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                btnSendKeyReleased(evt);
            }
        });

        btnSendFile.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        btnSendFile.setForeground(new java.awt.Color(0, 51, 51));
        btnSendFile.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/wc/images/clip.png"))); // NOI18N
        btnSendFile.setText("File");
        btnSendFile.setEnabled(false);
        btnSendFile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSendFileActionPerformed(evt);
            }
        });
        btnSendFile.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                btnSendFileKeyReleased(evt);
            }
        });

        jScrollPane3.setBorder(null);

        chatpane.setBackground(new java.awt.Color(51, 204, 255));
        chatpane.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(0, 51, 51)), "Messages", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 11), new java.awt.Color(0, 51, 51))); // NOI18N
        chatpane.setForeground(new java.awt.Color(0, 51, 51));

        jTextArea1.setEditable(false);
        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jTextArea1.setDisabledTextColor(new java.awt.Color(51, 0, 0));
        jTextArea1.setEnabled(false);
        jTextArea1.setSelectionColor(new java.awt.Color(0, 0, 0));
        jScrollPane4.setViewportView(jTextArea1);

        chatpane.addTab("All", jScrollPane4);

        jScrollPane3.setViewportView(chatpane);

        btnMail.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        btnMail.setForeground(new java.awt.Color(0, 51, 51));
        btnMail.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/wc/images/envelope.png"))); // NOI18N
        btnMail.setText("Mail");
        btnMail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMailActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 634, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jScrollPane6)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btnSend, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(btnSendFile, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnMail, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(87, 87, 87))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 267, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(btnSend, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnSendFile, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnMail, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 109, Short.MAX_VALUE)))
                .addContainerGap())
        );

        javax.swing.GroupLayout mainPanelLayout = new javax.swing.GroupLayout(mainPanel);
        mainPanel.setLayout(mainPanelLayout);
        mainPanelLayout.setHorizontalGroup(
            mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 793, Short.MAX_VALUE)
        );
        mainPanelLayout.setVerticalGroup(
            mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainPanelLayout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(mainPanel, javax.swing.GroupLayout.DEFAULT_SIZE, 805, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(mainPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 696, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public void sendAction() {
        String msg = txtMessage.getText();
        String target=listOnline.getSelectedValue().toString();
        JTextArea name = new JTextArea();
        String receiver[]=target.split(":");
//       if(chatwinindexlist.get(target)==null)
//       {
//          chatwinindexlist.put(target, chatpane.indexOfComponent(jTextArea1)+"");
//        chatwinlist.put(chatpane.indexOfComponent(jTextArea1)+"", jTextArea1);
//           chatpane.add(name,target);
//       }
                     
        if (!msg.isEmpty()) {
                if(receiver.length==1){
                    client.send(new Message("message", username, msg,target));
                }
                else {
                    DBQuery query = new DBQuery();
                    String toReceiver=receiver[0];
                    if (!msg.isEmpty()) {
                        query.saveMsg(username,toReceiver, msg);
                        this.servermes.append("Message sent.......\n");
                        txtMessage.setText("");
                    } 
                    else {
                        JOptionPane.showMessageDialog(null, "Error sending offline message");
                    }
            }
            txtMessage.setText("");
        }
        //chatpane.add();
    }
    
    private void btnSendActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSendActionPerformed
        sendAction();        
    }//GEN-LAST:event_btnSendActionPerformed

    void sendFileAction(){
        try {
            LookAndFeel x=UIManager.getLookAndFeel();
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            JFileChooser fileChooser = new JFileChooser();
            fileChooser.showDialog(this, "Select File");
            file = fileChooser.getSelectedFile();
            UIManager.setLookAndFeel(x);
            String target=listOnline.getSelectedValue().toString();
            String receiver[]=target.split(":");
            if (file != null) {
                if (!file.getName().isEmpty()) {
                    //btnSendFile.setEnabled(true);
                    String str;
                    str = file.getName();
                    if(str!=null){
                        this.servermes.append("Sending file........\n");
                    }
                    if(receiver.length==1){
                        sendFile();
                    }
                    else{
                        try {
                            query = new DBQuery();
                            String toReceiver=receiver[0];
                            query.saveFile(username,toReceiver,str);
                            sendFileOffline(receiver[0]);
                        } catch (IOException ex) {
                            Logger.getLogger(ChatFrame.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }
                }
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ChatFrame.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            Logger.getLogger(ChatFrame.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            Logger.getLogger(ChatFrame.class.getName()).log(Level.SEVERE, null, ex);
        } catch (UnsupportedLookAndFeelException ex) {
            Logger.getLogger(ChatFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void btnSendFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSendFileActionPerformed
        if(this.listOnline.getSelectedValue().toString().equals("All")){
            JOptionPane.showMessageDialog(null,"Sorry you cannot send file to all users!!!!");
        }else{
            sendFileAction();
        }
    }//GEN-LAST:event_btnSendFileActionPerformed

    
    
    private void txtMessageKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtMessageKeyReleased
        // TODO add your handling code here:
        if(evt.getKeyCode()== KeyEvent.VK_ENTER){
            sendAction();
        }
    }//GEN-LAST:event_txtMessageKeyReleased

    private void btnSendKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_btnSendKeyReleased
        // TODO add your handling code here:
        if(evt.getKeyCode()== KeyEvent.VK_ENTER){
            sendAction();
        }
    }//GEN-LAST:event_btnSendKeyReleased

    private void btnSendFileKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_btnSendFileKeyReleased
        // TODO add your handling code here:
        if(evt.getKeyCode()== KeyEvent.VK_ENTER){
            sendFileAction();
        }
    }//GEN-LAST:event_btnSendFileKeyReleased
    //method for offline messaging(halka error cha msg dui choti dekhaucha and duita message cha bhane first message matra display huncha)
    public void offlineMessage() throws SQLException{
           query=new DBQuery();
           String sql="select * from tbl_message";
           Statement stmt=query.con.createStatement();
           ResultSet rs=stmt.executeQuery(sql);
           while(rs.next()){
                String message=query.checkMsg(username);
                if (message != null) {
                    String parts[] = message.split(":"); 
                    String msgwhole;
                    String target = parts[1];
                    String sender = parts[0];
                    for(int i=2;i<parts.length;i++){
                        msgwhole=parts[i];
                        if (!msgwhole.isEmpty()) {
                            client.send(new Message("offline", sender, msgwhole, target));
                        }
                    }
                    query.remove(sender,target);
                }
           }
    }
    
    public void offlineFile() throws SQLException{
           query=new DBQuery();
           String sql="select * from tbl_file";
           Statement stmt=query.con.createStatement();
           ResultSet rs=stmt.executeQuery(sql);
           while(rs.next()){
                String file=query.checkFile(username);
                if (file != null) {
                    String parts[] = file.split(":"); 
                    String filewhole;
                    String target = parts[1];
                    String sender = parts[0];
                    for(int i=2;i<parts.length;i++){
                        filewhole=parts[i];
                        if (!filewhole.isEmpty()) {
                            client.send(new Message("offlineFile", sender, filewhole, target));
                        }
                    }
                    query.removeFile(sender,target);
                }
           }
    }
    
    private void listOnlineMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_listOnlineMouseClicked
         if(listOnline.getSelectedValue().toString().trim().equals("All")){
            btnSendFile.setEnabled(false);
            btnSendFile.repaint();
        }else{
            btnSendFile.setEnabled(true);
            btnSendFile.repaint();
        }
    }//GEN-LAST:event_listOnlineMouseClicked

    private void btnMailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMailActionPerformed
        CheckingInbox.getInstance(this).setVisible(rootPaneCheckingEnabled);
    }//GEN-LAST:event_btnMailActionPerformed

    private void btnViewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewActionPerformed
        try {
            new NoticeViewFrame(this.accountType,this).setVisible(true);
        } catch (SQLException ex) {
            Logger.getLogger(ChatFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnViewActionPerformed

    private void btnUserOptionsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUserOptionsActionPerformed
        new UserOptionsFrame(this);
    }//GEN-LAST:event_btnUserOptionsActionPerformed

    void sendFile() {
        long size = file.length();
        if (size < 120 * 1024 * 1024) {
            client.send(new Message("upload_req", username, file.getName(), listOnline.getSelectedValue().toString()));
        } else {
            servermes.append("File is size too large\n");
        }
    }
    
    void sendFileOffline(String receiver) throws IOException{
        long size = file.length();
        if (size < 120 * 1024 * 1024) {
                client.send(new Message("upload_req_offline", username, file.getName(),receiver));
            
        } else {
            servermes.append("File is size too large\n");
        }
    }
    
    public String[] onlineList(){
        String online[]=new String[50];
        for(int i=0;i<model.getSize();i++){
            online[i]=(String)model.getElementAt(i);
        }
        return online;
    }
  //list to show if somebody is offline(afu bahek sab lai dekhaucha aile)
    public void offlineList(){
              String online[]=new String[50];
              online=onlineList();
              String offline[]=new String[50];
              query=new DBQuery();
              offline=query.offline();
              int i=0;
              while(offline[i]!=null){
                    if(offline[i].equals(username)){
                        i++;
                        continue;
                    }
                    else{
                        int j=1;int flag=0;
                        while(online[j]!=null){
                            if(offline[i].equals(online[j])){
                                flag=1;
                                i++;
                                break;
                            }
                            j++;
                        }
                        if(flag!=1){
                            model.addElement(offline[i]+":offline");
                            i++;
                        }    
                    }
              }
}

public boolean isOffline(String user){
    String userPart[]=user.split(":");
    if(userPart[1].equals("offline")){
        return true;
    }
    return false;
}

public void checkNotice() throws ParseException, SQLException{
    DBQuery db=new DBQuery();
    int count=db.checkNewNotice(this.username);
    if(count>0){
        JOptionPane.showMessageDialog(this,"You have "+count+" new notices since u were last active!!!!!");
        try {
            new NoticeViewFrame(this.accountType,this).setVisible(true);
        } catch (SQLException ex) {
            Logger.getLogger(ChatFrame.class.getName()).log(Level.SEVERE, null, ex);
        }        
    }
}




    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JButton btnMail;
    public javax.swing.JButton btnSend;
    public javax.swing.JButton btnSendFile;
    public javax.swing.JButton btnUserOptions;
    public javax.swing.JButton btnView;
    public javax.swing.JTabbedPane chatpane;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    public javax.swing.JLabel jLabel6;
    private javax.swing.JLayeredPane jLayeredPane2;
    public javax.swing.JPanel jPanel1;
    public javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane6;
    public javax.swing.JTextArea jTextArea1;
    public javax.swing.JList listOnline;
    private javax.swing.JPanel mainPanel;
    public javax.swing.JTextArea servermes;
    private javax.swing.JTextArea txtMessage;
    // End of variables declaration//GEN-END:variables
}
