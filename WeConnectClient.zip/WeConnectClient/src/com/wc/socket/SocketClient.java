package com.wc.socket;

import com.wc.database.DBQuery;
import com.wc.logic.RecieveFile;
import com.wc.logic.Message;
import com.wc.logic.SendFile;
import com.wc.ui.ChatFrame;
import java.io.*;
import java.net.*;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.LookAndFeel;
import javax.swing.UIManager;

public class SocketClient implements Runnable {

    public int port;
    public String serverAddr;
    public Socket socket;
    public ChatFrame ui;
    public ObjectInputStream In;
    public ObjectOutputStream Out;

    public SocketClient(ChatFrame frame) throws IOException {

        ui = frame;
        this.serverAddr = ui.serverAddr;
        this.port = ui.port;
        socket = new Socket(InetAddress.getByName(serverAddr), port);

        Out = new ObjectOutputStream(socket.getOutputStream());
        Out.flush();
        In = new ObjectInputStream(socket.getInputStream());

    }

    @Override
   public void run() {
       boolean keepRunning = true;
       DBQuery db=new DBQuery();
       ui.offlineList();
        try {
            ui.offlineMessage();
            ui.offlineFile();
        } catch (SQLException ex) {
            Logger.getLogger(SocketClient.class.getName()).log(Level.SEVERE, null, ex);
        }
        while (keepRunning) {
            try {
                Message msg = (Message) In.readObject();
                System.out.println("Incoming : " + msg.toString());

                if (msg.type.equals("message") && !msg.sender.equalsIgnoreCase("server")) {

                    if ((msg.reciever.equals(ui.username) || msg.sender.equals(ui.username)) && !(msg.reciever.equals("All") || msg.sender.equals("All"))) {

                        String index = null;
                        if (ui.chatwinindexlist.get(msg.reciever) == null && ui.chatwinindexlist.get(msg.sender) == null) {
                            JTextArea name = new JTextArea();
                            name.setEditable(false);
                            if (msg.reciever.equals(ui.username)) {
                                ui.chatwinindexlist.put(msg.sender, ui.chatpane.indexOfComponent(name) + "");
                                ui.chatwinlist.put(ui.chatpane.indexOfComponent(name) + "", name);
                                ui.chatpane.add(new JScrollPane().add(name), msg.sender);
                                name.requestFocus();

                            } else {
                                ui.chatwinindexlist.put(msg.reciever, ui.chatpane.indexOfComponent(name) + "");
                                ui.chatwinlist.put(ui.chatpane.indexOfComponent(name) + "", name);
                                ui.chatpane.add(new JScrollPane().add(name), msg.reciever);
                                //  ui.addCloseableTab(ui.chatpane, msg.reciever, name);
                                name.requestFocus();
                            }
                        }
                        if (msg.reciever.equals(ui.username)) {
                            index = (String) ui.chatwinindexlist.get(msg.sender);
                        } else {
                            index = (String) ui.chatwinindexlist.get(msg.reciever);
                        }
                        ((JTextArea) ui.chatwinlist.get(index)).requestFocus();
                        ((JTextArea) ui.chatwinlist.get(index)).append("[" + msg.sender + "-->] : " + msg.content + "\n");
                    } else {
                        ui.jTextArea1.append("[" + msg.sender + "-->] : " + msg.content + "\n");
                    }

                } else if (msg.type.equals("login")) {
                    if (msg.content.equals("TRUE")) {

                        ui.btnSend.setEnabled(true);
                        ui.btnSendFile.setEnabled(true);
                        ui.servermes.append("Login Successful\n");
                        ui.servermes.setEnabled(false);
                        db.updateStatus(this.ui.username,"NO");
                        ui.jPanel1.show();
//                        ui.jPanel4.show();
                        ui.jLabel6.setText("Hello, " + ui.username + "!");
                        ui.jLabel6.show();
                        try {
                            ui.checkNotice();
                        } catch (ParseException ex) {
                            Logger.getLogger(SocketClient.class.getName()).log(Level.SEVERE, null, ex);
                        } catch (SQLException ex) {
                            Logger.getLogger(SocketClient.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    } else {
                        JOptionPane.showMessageDialog(ui, "Login Failed");
                    }
                } else if (msg.type.equals("test")) {
//                    ui.jButton7.setEnabled(true);
                } else if (msg.type.equals("newuser")) {
                    if (!msg.content.equals(ui.username)) {
                        boolean exists = false;
                        for (int i = 0; i < ui.model.getSize(); i++) {
                            if (ui.model.getElementAt(i).equals(msg.content)) {
                                exists = true;
                                break;
                            }
                        }
                        if (!exists) {
                            ui.model.addElement(msg.content);
                            String checkName=new String(msg.content+":offline");
                            for(int i=0;i<ui.model.getSize();i++){
                                if(ui.model.getElementAt(i).equals(checkName)){
                                    ui.model.removeElementAt(i);
                                }
                            }
                        }
                    }
                } else if(msg.type.equals("deleted")){
                    ui.model.removeElement(msg.content+":offline");
                    ui.servermes.append("User "+msg.content+" has been deleted!!!!\n");
                }
                else if(msg.type.equals("added")){
                    ui.model.addElement(msg.content+":offline");
                    ui.servermes.append("User "+msg.content+" has joined WE-Connect!!!!\n");
                }
                else if(msg.type.equals("modified")){
                    String value[]=msg.content.split(":");
                    ui.model.removeElement(value[1]+":offline");
                    ui.model.addElement(value[0]+":offline");
                    ui.servermes.append("User "+value[1]+" changed username to "+value[0]+" !!!!!!\n");
                }
                else if(msg.type.equals("noticeAdd")){
                    String value[]=msg.content.split(":");
                    JOptionPane.showMessageDialog(ui,"New notice: "+value[0]+"-"+value[1]+"\n");
                }
                else if(msg.type.equals("noticeModified")){
                    String value[]=msg.content.split(":");
                    JOptionPane.showMessageDialog(ui,"Notice updated: "+value[0]+"-"+value[1].substring(0,10)+"\n");
                }
                else if (msg.type.equals("signout")) {
                    if (msg.content.equals(ui.username)) {
                        ui.servermes.append("Bye\n");
                        ui.btnSend.setEnabled(false);

                        for (int i = 1; i < ui.model.size(); i++) {
                            ui.model.removeElementAt(i);
                        }

                        ui.clientThread.stop();
                    } else {
                        ui.model.removeElement(msg.content);
                        ui.model.addElement(msg.content+":offline");
                        ui.servermes.append(msg.content + " has signed out\n");
                    }
                } else if (msg.type.equals("upload_req")) {
                    if(JOptionPane.showConfirmDialog(ui, "Accept '" + msg.content + "' from " + msg.sender + " ?", "File accept", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION){
                        LookAndFeel x=UIManager.getLookAndFeel();
                        UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
                        JFileChooser jf = new JFileChooser();
                        jf.setSelectedFile(new File(msg.content));
                        int returnVal = jf.showSaveDialog(ui);
                        UIManager.setLookAndFeel(x);
                        String saveTo = jf.getSelectedFile().getPath();
                        JOptionPane.showMessageDialog(null,saveTo);
                        if (saveTo != null && returnVal == JFileChooser.APPROVE_OPTION) {
                            RecieveFile dwn = new RecieveFile(saveTo, ui);
                            Thread t = new Thread(dwn);
                            t.start();
                            //send(new Message("upload_res", (""+InetAddress.getLocalHost().getHostAddress()), (""+dwn.port), msg.sender));
                            send(new Message("upload_res", ui.username, ("" + dwn.port), msg.sender));
                        } else {
                            send(new Message("upload_res", ui.username, "NO", msg.sender));
                        }
                    } else {
                        send(new Message("upload_res", ui.username, "NO", msg.sender));
                    }
                }   
                else if(msg.type.equals("upload_req_offline_check")){
                    if(JOptionPane.showConfirmDialog(ui, "Accept '" + msg.content + "' from " + msg.sender + " ?", "File accept", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION){
                        LookAndFeel x = UIManager.getLookAndFeel();
                        UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
                        JFileChooser jf = new JFileChooser();
                        jf.setSelectedFile(new File(msg.content));
                        int returnVal = jf.showSaveDialog(ui);
                        String saveTo = jf.getSelectedFile().getPath();
                        UIManager.setLookAndFeel(x);
                        JOptionPane.showMessageDialog(null, saveTo);
                        if (saveTo != null && returnVal == JFileChooser.APPROVE_OPTION) {
                            RecieveFile dwn = new RecieveFile(saveTo, ui);
                            Thread t = new Thread(dwn);
                            t.start();
                            //send(new Message("upload_res", (""+InetAddress.getLocalHost().getHostAddress()), (""+dwn.port), msg.sender));
                            //String IP = Inet4Address.getLocalHost().getHostAddress();
                            String IP = socket.getLocalAddress().getHostAddress();
                            send(new Message("upload_res_offline",IP, ("" + dwn.port), msg.content));
                        } else {
                            send(new Message("upload_res_offline", ui.username, "NO", msg.content));
                        }
                    } else {
                        send(new Message("upload_res_offline", ui.username, "NO", msg.sender));
                    }
                }
                else if (msg.type.equals("upload_res")) {
                    if (!msg.content.equals("NO")) {
                            int port = Integer.parseInt(msg.content);
                            String addr = msg.sender;
                            ui.btnSendFile.setEnabled(false);
                            SendFile upl = new SendFile(addr, port, ui.file, ui);
                            Thread t = new Thread(upl);
                            t.start();
                    } 
                    else {
                        ui.servermes.append(msg.sender + " rejected file request\n");
                    }
                } 
                else {
                    ui.servermes.append("Unknown message type\n");
                }
            } catch (Exception ex) {
                keepRunning = false;
                ex.printStackTrace();
                ui.servermes.append("Connection Failure\n");
                JOptionPane.showMessageDialog(ui, "Conection Failure");
                ui.btnSend.setEnabled(false);
                ui.btnSendFile.setEnabled(false);
                ui.btnSendFile.setEnabled(false);

                for (int i = 1; i < ui.model.size(); i++) {
                    ui.model.removeElementAt(i);
                }

                ui.clientThread.stop();

                System.out.println("Exception SocketClient run()");
                ex.printStackTrace();
            }
        }
    }

    public void send(Message msg) {
        try {
            Out.writeObject(msg);
            Out.flush();
            System.out.println("Outgoing : " + msg.toString());

        } catch (IOException ex) {
            ex.printStackTrace();
            System.out.println("Exception SocketClient send()");
        }
    }

    public void closeThread(Thread t) {
        t = null;
    }
}
