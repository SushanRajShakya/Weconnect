package com.wc.mailView;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Partha
 */
import com.sun.mail.util.MailConnectException;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.mail.Address;
import javax.mail.AuthenticationFailedException;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.NoSuchProviderException;
import javax.mail.Part;
import javax.mail.Session;
import javax.mail.Store;
import javax.swing.JFileChooser;
import javax.swing.table.DefaultTableModel;

public class EmailFetcher {

    Thread actionFetch = new Thread();
    Folder emailFolder;
    Store store;
    Message[] messages, unreadMessages;
    public static Session emailSession;

    public static EmailFetcher ef = null;

    public static EmailFetcher getInstance() {
        if (ef == null) {
            ef = new EmailFetcher();
        }
        return ef;
    }

    public void closeStore() throws MessagingException {
        if (emailFolder != null) {
            if (emailFolder.isOpen()) {
                emailFolder.close(false);
            }
        }
        if (store != null) {
            if (store.isConnected()) {
                store.close();
            }
        }
    }

    public void fetch(final CheckingInbox frame) {
        if (actionFetch.isAlive()) {
            return;
        }
        actionFetch = new Thread() {
            @Override
            public void run() {

                try {
                    closeStore();
                    // create properties field
                    Properties properties = new Properties();
                    properties.put("mail.store.protocol", "pop3s");
                    properties.put("mail.pop3.host", "pop.gmail.com");
                    properties.put("mail.pop3.port", "995");
                    properties.put("mail.pop3.starttls.enable", "true");
                    emailSession = Session.getDefaultInstance(properties);
                    //emailSession.setDebug(true);

                    // create the POP3 store object and connect with the pop server
                    store = emailSession.getStore("pop3s");

                    store.connect("pop.gmail.com", frame.txtUser.getText().trim(), frame.txtPassword.getText().trim());
                    frame.btnCompose.setEnabled(true);
                    // create the folder object and open it
                    emailFolder = store.getFolder("INBOX");
                    emailFolder.open(Folder.READ_ONLY);

                    // retrieve the messages from the folder in an array and print it
                    messages = emailFolder.getMessages();

                    System.out.println("messages.length---" + messages.length);
                    if (messages.length == 0) {
                        //System.out.println("No messages found.");
                        frame.lblMsgCount.setText("No messages found.");
                    } else {
                        frame.lblMsgCount.setText(messages.length + " messages found.");
                    }
                    ((DefaultTableModel) frame.tblEmails.getModel()).setRowCount(0);
                    for (int i = messages.length - 1, n = 0; i >= 0; i--, n++) {

                        ((DefaultTableModel) frame.tblEmails.getModel()).addRow(new Object[][]{null, null, null, null});
                        frame.tblEmails.setValueAt(i + 1, n, 0);
                        frame.tblEmails.setValueAt(messages[i].getFrom()[0], n, 1);
                        frame.tblEmails.setValueAt(messages[i].getSubject(), n, 2);
                        frame.tblEmails.setValueAt(messages[i].getSentDate(), n, 3);

//                System.out.println("Message " + (i + 1));
//                System.out.println("From : " + messages[i].getFrom()[0]);
//                System.out.println("Subject : " + messages[i].getSubject());
//                System.out.println("Sent Date : " + messages[i].getSentDate());
                        //System.out.println();
                    }

                } catch (NoSuchProviderException e) {
                    e.printStackTrace();
                    frame.btnLogin.setEnabled(true);
                    frame.btnCompose.setEnabled(false);
                } catch (MailConnectException e) {
                    e.printStackTrace();
                    frame.lblMessage.setText("Error message: No internet access");
                    frame.btnLogin.setEnabled(true);
                    frame.btnCompose.setEnabled(false);
                } catch (AuthenticationFailedException e) {
                    e.printStackTrace();
                    frame.lblMessage.setText("Error message: Username or Password incorrect OR Please allow mail access authorization by following the link given below");
                    frame.txtmessage.setVisible(true);
                    frame.txtmessage.setText("https://support.google.com/mail/answer/78754");
                    frame.txtmessage.setEditable(false);
                    frame.btnLogin.setEnabled(true);
                    frame.btnCompose.setEnabled(false);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        };

        while (true) {
            if (!actionFetch.isAlive()) {
                actionFetch.start();
                break;
            }

        }
    }

    /*
     * This method checks for content-type 
     * based on which, it processes and
     * fetches the content of the message
     */
    Thread actionWritePart = new Thread();

    public void writePart(final Part p, FrmMailDetail fmd) {
        try {

            //check if the content is plain text
            if (p.isMimeType("text/html")) {

                String msgTxt = (String) p.getContent();
                if (!msgTxt.contains("<html>")) {
                    fmd.txtMsgBox.setText("<html>" + (String) p.getContent() + "</html>");
                } else {
                    fmd.txtMsgBox.setText((String) p.getContent());
                }
            } //check if the content has attachment
            else if (p.isMimeType("multipart/*")) {

                Multipart mp = (Multipart) p.getContent();
                int count = 0;
                count = mp.getCount();

                for (int i = 0; i < count; i++) {
                    writePart(mp.getBodyPart(i), fmd);
                }
            } //check if the content is a nested message
            else if (p.isMimeType("message/rfc822")) {

                writePart((Part) p.getContent(), fmd);
            } else {
                if (actionWritePart.isAlive()) {
                    return;
                }
                actionWritePart = new Thread() {
                    @Override
                    public void run() {

                        try {
                            Object o = p.getContent();
                            if (o instanceof String) {
                                String name = p.getContentType().split("name")[1];
                                if (name.equals("")) {
                                    return;
                                }
                                name = name.replaceAll("\"", "");
                                name = name.replaceAll("=", "");
                                JFileChooser locationChooser = new JFileChooser();
                                //pathExtractor.setCurrentDirectory(new java.io.File("."));
                                locationChooser.setDialogTitle("Save as Excel");
                                locationChooser.setSelectedFile(new File(name));
                                String filepath = "WeConnect";
                                int retVal = locationChooser.showSaveDialog(null);
                                if (retVal == JFileChooser.APPROVE_OPTION) {
                                    filepath = locationChooser.getSelectedFile().getAbsolutePath();
                                    File file = new File(filepath);
                                    FileWriter fw = new FileWriter(file);
                                    fw.write((String) o, 0, ((String) o).length());
                                    fw.close();
                                }

                            } else if (o instanceof InputStream) {
                                String name = p.getContentType().split("name")[1];
                                if (name.equals("")) {
                                    return;
                                }
                                name = name.replaceAll("\"", "");
                                name = name.replaceAll("=", "");
                                JFileChooser locationChooser = new JFileChooser();
                                //pathExtractor.setCurrentDirectory(new java.io.File("."));
                                locationChooser.setDialogTitle("Save as Excel");
                                locationChooser.setSelectedFile(new File(name));
                                String filepath = "WeConnect";
                                int retVal = locationChooser.showSaveDialog(null);
                                if (retVal == JFileChooser.APPROVE_OPTION) {
                                    filepath = locationChooser.getSelectedFile().getAbsolutePath();
                                    InputStream is = (InputStream) o;
                                    File file = new File(filepath);
                                    OutputStream op = new FileOutputStream(file);

                                    is = (InputStream) o;

                                    int c;
                                    while ((c = is.read()) != -1) {
                                        op.write(c);
                                    }
                                    op.close();
                                }

                            } else {
                                System.out.println("This is an unknown type");
                                System.out.println("---------------------------");
                                System.out.println(o.toString());

                            }
                        } catch (IOException ex) {
                            Logger.getLogger(EmailFetcher.class.getName()).log(Level.SEVERE, null, ex);
                        } catch (MessagingException ex) {
                            Logger.getLogger(EmailFetcher.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }
                };
                while (true) {
                    if (!actionWritePart.isAlive()) {
                        actionWritePart.start();
                        break;
                    }

                }
            }
        } catch (Exception ex) {

        }

    }
    /*
     * This method would print FROM,TO and SUBJECT of the message
     */

    public void writeEnvelope(FrmMailDetail fmd) throws Exception {
        Address[] a;
        // FROM
        if ((a = fmd.message.getFrom()) != null) {
            fmd.lblFrom.setText("From: " + a[0].toString().trim());
        }

        // TO
        if ((a = fmd.message.getRecipients(Message.RecipientType.TO)) != null) {
            String to = "<html>TO: ";
            for (int j = 0; j < a.length; j++) {
                to += a[j].toString() + "<br/>";
            }
            to += "</html>";
            fmd.lblTo.setText(to);
        }

        // SUBJECT
        if (fmd.message.getSubject() != null) {
            fmd.lblSubject.setText("SUBJECT: " + fmd.message.getSubject());
        }

    }

}
