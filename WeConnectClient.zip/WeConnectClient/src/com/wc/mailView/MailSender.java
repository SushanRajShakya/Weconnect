package com.wc.mailView;



/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.Properties;
import javax.mail.AuthenticationFailedException;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

/**
 *
 * @author partha
 */
public class MailSender {

    public void sendMail(EmailCompose emailCompose) {

        String from = "WeConnect";
        String subject = emailCompose.txtSubject.getText().trim();
        String message = emailCompose.txtContent.getText().trim();
        String password =emailCompose.password;
        String login = emailCompose.userName;

        try {
            Properties props = new Properties();
            props.setProperty("mail.host", "smtp.gmail.com");
            props.setProperty("mail.smtp.port", "587");
            props.setProperty("mail.smtp.auth", "true");
            props.setProperty("mail.smtp.starttls.enable", "true");

            Authenticator auth = new SMTPAuthenticator(login, password);

            Session session = Session.getInstance(props,auth);

            MimeMessage msg = new MimeMessage(session);
            msg.setText(message);
            msg.setSubject(subject);
            msg.setFrom(new InternetAddress(login));
            msg.addRecipient(Message.RecipientType.TO, new InternetAddress(emailCompose.txtTo.getText().trim()));
            
            
//            Pattern emailAddressReges = Pattern.compile(
//                    "^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$",
//                    Pattern.CASE_INSENSITIVE);
//
//            for (int i = 0; i < bcc.size(); i++) {
//                Matcher matcher = emailAddressReges.matcher(bcc.get(i).toString().trim());
//                if (matcher.find()) {
//                    msg.addRecipient(Message.RecipientType.BCC, new InternetAddress(bcc.get(i).toString().trim()));
//                }
//            }
            Transport.send(msg);

        } catch (AuthenticationFailedException ex) {
            ex.printStackTrace();

        } catch (AddressException ex) {
            ex.printStackTrace();
        } catch (MessagingException ex) {
            ex.printStackTrace();
        }

    }

    private class SMTPAuthenticator extends Authenticator {

        private PasswordAuthentication authentication;

        public SMTPAuthenticator(String login, String password) {
            authentication = new PasswordAuthentication(login, password);
        }

        protected PasswordAuthentication getPasswordAuthentication() {
            return authentication;
        }
    }

}
