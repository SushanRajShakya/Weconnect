/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.wc.mailView;

import java.io.File;
import java.util.ArrayList;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.swing.JOptionPane;

/**
 *
 * @author Pravesh
 */
public class EmailLogic {
    public String host;
    public String port;
    public String userName;
    public String subject;
    public String password;
    public ArrayList al;
    public String to;
    EmailCompose ui;
    public EmailLogic(String host, String port, String userName, String password,ArrayList al,String to,EmailCompose ui,String subject) {
        this.host = host;
        this.port = port;
        this.userName = userName;
        this.password = password;
        this.al =al;
        this.to=to;
        this.ui=ui;
        this.subject=subject;
    }
    
    
    
    
    public boolean sendEmail() throws MessagingException{
        try {
            
            Properties props = new Properties();
            props.put("mail.smtp.auth", "true");
            props.put("mail.smtp.starttls.enable", "true");
            props.put("mail.smtp.host",host);
            props.put("mail.smtp.port",port);
            
            Session session = Session.getInstance(props,new javax.mail.Authenticator() {
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(userName, password);
                }
            });
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress("from-email@gmail.com"));
            message.setRecipients(Message.RecipientType.TO,
                    InternetAddress.parse(to));
            message.setSubject(this.subject);
            BodyPart msgBdyPart=new MimeBodyPart();
            msgBdyPart.setText(ui.txtContent.getText());
            //create multipart
            Multipart multipart=new MimeMultipart();
            //set text messafe part
            multipart.addBodyPart(msgBdyPart);
            
            for(int i=0;i<al.size();i++)
            {
            //part two attachments
                        msgBdyPart=new MimeBodyPart();
                        DataSource source=new FileDataSource((String)al.get(i));
                        msgBdyPart.setDataHandler(new DataHandler(source));
                        msgBdyPart.setFileName((String)al.get(i));
                        multipart.addBodyPart(msgBdyPart);
                        
            }
          message.setContent(multipart);
            
            Transport.send(message);
            JOptionPane.showMessageDialog(null,"Message sent sucessfully");
            
        } catch (AddressException ex) {
            Logger.getLogger(EmailLogic.class.getName()).log(Level.SEVERE, null, ex);
        }
    return false;
    }
    
    
}
